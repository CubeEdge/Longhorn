import React, { useState, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Plus, Search, ChevronLeft, ChevronRight, Phone, Mail, MessageSquare, Clock, CheckCircle, ArrowUpCircle, Loader2, XCircle, AlertCircle, AlertTriangle, LayoutGrid } from 'lucide-react';
import { formatDistanceToNow, differenceInHours, subDays, format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { useLanguage } from '../../i18n/useLanguage';
import { useTicketStore } from '../../store/useTicketStore';
import { useCachedTickets } from '../../hooks/useCachedTickets';


interface InquiryTicket {
    id: number;
    ticket_number: string;
    service_type: string;
    channel: string;
    customer_name: string;
    dealer_name?: string;
    problem_summary: string;
    status: string;
    handler: { id: number; name: string } | null;
    product: { id: number; name: string } | null;
    serial_number: string;
    created_at: string;
    updated_at: string;
    product_family?: string;
}

const statusColors: Record<string, string> = {
    InProgress: '#3b82f6',
    AwaitingFeedback: '#8b5cf6',
    Resolved: '#10b981',
    AutoClosed: '#6b7280',
    Upgraded: '#06b6d4'
};

const channelIcons: Record<string, React.ReactNode> = {
    Phone: <Phone size={14} />,
    Email: <Mail size={14} />,
    WeChat: <MessageSquare size={14} />,
    WeCom: <MessageSquare size={14} />,
    Facebook: <MessageSquare size={14} />,
    Online: <MessageSquare size={14} />
};

const InquiryTicketListPage: React.FC = () => {
    // Removed unused token and useEffect
    const { t } = useLanguage();
    const navigate = useNavigate();
    const [searchParams, setSearchParams] = useSearchParams();
    const openModal = useTicketStore(state => state.openModal);

    const [page, setPage] = useState(1);
    const [pageSize] = useState(50);

    const [showDatePicker, setShowDatePicker] = useState(false);
    const [customRange, setCustomRange] = useState({ start: '', end: '' });

    // Scope Filters
    const timeScope = searchParams.get('time_scope') || '7d';
    const productFamilyScope = searchParams.get('product_family') || 'all'; // Standardized param name
    const searchTerm = searchParams.get('keyword') || '';
    const statusFilter = searchParams.get('status') || 'all';
    const viewModeParam = searchParams.get('view') || 'list'; // New View Mode

    // Local States
    const [viewMode, setViewMode] = useState<'list' | 'card'>(viewModeParam as 'list' | 'card');
    const [customFamilyOpen, setCustomFamilyOpen] = useState(false);
    const [selectedFamilies, setSelectedFamilies] = useState<string[]>([]); // For custom combo

    // Build params for SWR hook
    const queryParams = useMemo(() => {
        const params: Record<string, string | number | undefined> = {
            page,
            page_size: pageSize
        };

        // Apply time scope
        if (timeScope === '7d') {
            params.created_from = format(subDays(new Date(), 7), 'yyyy-MM-dd');
        } else if (timeScope === '30d') {
            params.created_from = format(subDays(new Date(), 30), 'yyyy-MM-dd');
        } else if (timeScope === 'custom') {
            const start = searchParams.get('start_date');
            const end = searchParams.get('end_date');
            if (start) params.created_from = start;
            if (end) params.created_to = end;
        }

        if (productFamilyScope !== 'all') params.product_family = productFamilyScope;
        if (searchTerm) params.keyword = searchTerm;
        if (statusFilter !== 'all') params.status = statusFilter;

        return params;
    }, [page, pageSize, timeScope, productFamilyScope, searchTerm, statusFilter, searchParams]);

    // SWR-based data fetching
    const { tickets, meta, isLoading } = useCachedTickets<InquiryTicket>('inquiry', queryParams);
    const total = meta.total;

    const updateFilter = (newParams: Record<string, string>) => {
        const current = Object.fromEntries(searchParams.entries());
        setSearchParams({ ...current, ...newParams });
        setPage(1);
    };

    const handleTimeSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const val = e.target.value;
        if (val === 'custom') {
            setShowDatePicker(true);
        } else {
            updateFilter({ time_scope: val, start_date: '', end_date: '' });
        }
    };

    const applyCustomDate = () => {
        if (customRange.start && customRange.end) {
            updateFilter({
                time_scope: 'custom',
                start_date: customRange.start,
                end_date: customRange.end
            });
            setShowDatePicker(false);
        }
    };

    // Product Family Definitions
    const productFamilies = [
        { id: 'all', label: t('filter.all_products') },
        { id: 'MAVO Edge', label: 'MAVO Edge (6K/8K)' },
        { id: 'MAVO', label: 'MAVO (LF/S35)' },
        { id: 'TERRA', label: 'TERRA (4K/6K)' },
        { id: 'Accessories', label: 'Accessories' }
    ];

    const handleFamilySelect = (val: string) => {
        if (val === 'custom') {
            setCustomFamilyOpen(true);
        } else {
            updateFilter({ product_family: val });
        }
    };

    const applyCustomFamilies = () => {
        updateFilter({ product_family: selectedFamilies.join(',') });
        setCustomFamilyOpen(false);
    };

    const toggleViewMode = (mode: 'list' | 'card') => {
        setViewMode(mode);
        updateFilter({ view: mode });
    };

    // Smart Grouping Logic ("Pulse")
    const groupedTickets = useMemo(() => {
        const groups = {
            urgent: [] as InquiryTicket[],
            attention: [] as InquiryTicket[],
            active: [] as InquiryTicket[],
            done: [] as InquiryTicket[]
        };

        const now = new Date();

        tickets.forEach(ticket => {
            const isDone = ['Resolved', 'AutoClosed', 'Upgraded'].includes(ticket.status);
            if (isDone) {
                groups.done.push(ticket);
                return;
            }

            const hoursSinceUpdate = differenceInHours(now, new Date(ticket.updated_at));

            if (hoursSinceUpdate > 72) { // 3 days
                groups.urgent.push(ticket);
            } else if (hoursSinceUpdate > 24) {
                groups.attention.push(ticket);
            } else {
                groups.active.push(ticket);
            }
        });

        return groups;
    }, [tickets]);

    const totalPages = Math.ceil(total / pageSize);

    const getStatusIcon = (status: string) => {
        switch (status) {
            case 'InProgress': return <Loader2 size={14} className="animate-spin-slow" />;
            case 'AwaitingFeedback': return <Clock size={14} />;
            case 'Resolved': return <CheckCircle size={14} />;
            case 'AutoClosed': return <XCircle size={14} />;
            case 'Upgraded': return <ArrowUpCircle size={14} />;
            default: return <Clock size={14} />;
        }
    };

    const getStatusLabel = (status: string) => {
        const labels: Record<string, string> = {
            InProgress: t('inquiry_ticket.status.in_progress'),
            AwaitingFeedback: t('inquiry_ticket.status.awaiting_feedback'),
            Resolved: t('inquiry_ticket.status.resolved'),
            AutoClosed: t('inquiry_ticket.status.auto_closed'),
            Upgraded: t('inquiry_ticket.status.upgraded')
        };
        return labels[status] || status;
    };

    const TicketCard = ({ ticket }: { ticket: InquiryTicket }) => {
        const isUrgent = !['Resolved', 'AutoClosed', 'Upgraded'].includes(ticket.status) && differenceInHours(new Date(), new Date(ticket.updated_at)) > 72;
        const family = ticket.product_family || (ticket.product ? 'Unknown' : null);

        return (
            <div
                onClick={() => navigate(`/service/inquiry-tickets/${ticket.id}`)}
                className="group"
                style={{
                    background: 'var(--bg-card)',
                    borderRadius: '8px',
                    padding: '16px 20px',
                    borderLeft: isUrgent ? '4px solid #ef4444' : '4px solid transparent',
                    borderTop: '1px solid var(--border-color)',
                    borderRight: '1px solid var(--border-color)',
                    borderBottom: '1px solid var(--border-color)',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    position: 'relative'
                }}
                onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-1px)';
                    e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.05)';
                    e.currentTarget.style.borderColor = 'var(--primary)';
                }}
                onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'none';
                    e.currentTarget.style.boxShadow = 'none';
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                }}
            >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div style={{ flex: 1, minWidth: 0, paddingRight: '20px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                            <h3 style={{
                                fontSize: '1rem',
                                fontWeight: 600,
                                color: 'var(--text-primary)',
                                whiteSpace: 'nowrap',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis'
                            }}>
                                {ticket.problem_summary}
                            </h3>
                            {ticket.product && (
                                <span style={{
                                    fontSize: '0.75rem',
                                    padding: '2px 6px',
                                    borderRadius: '4px',
                                    background: 'var(--bg-tertiary)',
                                    color: 'var(--text-secondary)',
                                    whiteSpace: 'nowrap',
                                    border: '1px solid rgba(255,255,255,0.05)'
                                }}>
                                    {ticket.product.name}
                                </span>
                            )}
                            {family && family !== 'Unknown' && (
                                <span style={{
                                    fontSize: '0.70rem',
                                    padding: '2px 6px',
                                    borderRadius: '4px',
                                    background: 'rgba(234, 179, 8, 0.1)',
                                    color: '#eab308',
                                    whiteSpace: 'nowrap',
                                    fontWeight: 600,
                                    textTransform: 'uppercase'
                                }}>
                                    {family}
                                </span>
                            )}
                        </div>

                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
                            {ticket.dealer_name && (
                                <span style={{ color: 'var(--primary)', fontWeight: 500 }}>
                                    {ticket.dealer_name}
                                </span>
                            )}
                            {ticket.dealer_name && <span>·</span>}
                            <span>{ticket.customer_name || '匿名客户'}</span>
                            <span style={{ display: 'flex', alignItems: 'center', gap: '4px', color: 'var(--text-tertiary)' }}>
                                {ticket.channel && channelIcons[ticket.channel]}
                                #{ticket.ticket_number}
                            </span>
                            {ticket.handler && (
                                <span style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginLeft: '8px' }}>
                                    Op: {ticket.handler.name}
                                </span>
                            )}
                        </div>
                    </div>

                    <div style={{ textAlign: 'right', flexShrink: 0 }}>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '6px' }}>
                            <span
                                style={{
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '4px',
                                    padding: '4px 10px',
                                    borderRadius: '20px',
                                    fontSize: '0.75rem',
                                    fontWeight: 600,
                                    background: `${statusColors[ticket.status] || '#6b7280'}15`,
                                    color: statusColors[ticket.status] || '#6b7280'
                                }}
                            >
                                {getStatusIcon(ticket.status)}
                                {getStatusLabel(ticket.status)}
                            </span>

                            <span style={{
                                fontSize: '0.75rem',
                                color: isUrgent ? '#ef4444' : 'var(--text-tertiary)',
                                fontWeight: isUrgent ? 600 : 400,
                                display: 'flex',
                                alignItems: 'center',
                                gap: '4px'
                            }}>
                                {isUrgent && <AlertCircle size={12} />}
                                {formatDistanceToNow(new Date(ticket.updated_at), { addSuffix: true, locale: zhCN })}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div style={{ padding: '24px', maxWidth: '1400px', margin: '0 auto' }}>
            {/* Header Area */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
                <h1 style={{ fontSize: '1.8rem', fontWeight: 700, margin: 0 }}>{t('inquiry_ticket.title')}</h1>
                <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                    {/* View Mode Toggle */}
                    <div style={{ background: 'var(--bg-card)', padding: '2px', borderRadius: '8px', border: '1px solid var(--border-color)', display: 'flex', marginRight: '16px' }}>
                        <button
                            onClick={() => toggleViewMode('list')}
                            style={{
                                padding: '6px',
                                borderRadius: '6px',
                                border: 'none',
                                background: viewMode === 'list' ? 'var(--primary)' : 'transparent',
                                color: viewMode === 'list' ? '#fff' : 'var(--text-secondary)',
                                cursor: 'pointer',
                                display: 'flex', alignItems: 'center', justifyContent: 'center'
                            }}
                            title="List View"
                        >
                            <LayoutGrid size={18} style={{ transform: 'rotate(90deg)' }} />
                        </button>
                        <button
                            onClick={() => toggleViewMode('card')}
                            style={{
                                padding: '6px',
                                borderRadius: '6px',
                                border: 'none',
                                background: viewMode === 'card' ? 'var(--primary)' : 'transparent',
                                color: viewMode === 'card' ? '#fff' : 'var(--text-secondary)',
                                cursor: 'pointer',
                                display: 'flex', alignItems: 'center', justifyContent: 'center'
                            }}
                            title="Card View"
                        >
                            <LayoutGrid size={18} />
                        </button>
                    </div>

                    <button
                        onClick={() => openModal('Inquiry')}
                        className="btn btn-primary"
                        style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                    >
                        <Plus size={18} />
                        {t('inquiry_ticket.create')}
                    </button>
                </div>
            </div>

            {/* Filters Row */}
            <div style={{ display: 'flex', gap: '16px', marginBottom: '24px', flexWrap: 'wrap', alignItems: 'center' }}>
                {/* Search */}
                <div style={{ position: 'relative', minWidth: '240px' }}>
                    <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-secondary)' }} />
                    <input
                        type="text"
                        placeholder={t('action.search') + "..."}
                        defaultValue={searchTerm}
                        onBlur={(e) => updateFilter({ keyword: e.target.value })}
                        onKeyDown={(e) => e.key === 'Enter' && updateFilter({ keyword: e.currentTarget.value })}
                        className="form-control"
                        style={{ paddingLeft: '36px', height: '40px' }}
                    />
                </div>

                {/* Product Family Filter */}
                <select
                    value={productFamilyScope.includes(',') ? 'custom' : productFamilyScope}
                    onChange={(e) => handleFamilySelect(e.target.value)}
                    className="form-control"
                    style={{ width: 'auto', minWidth: '160px', height: '40px' }}
                >
                    <option value="all">{t('filter.all_products')}</option>
                    <option value="MAVO Edge">MAVO Edge Series</option>
                    <option value="MAVO">MAVO Series</option>
                    <option value="TERRA">TERRA Series</option>
                    <option value="Accessories">Accessories</option>
                    <option value="custom">Custom...</option>
                </select>

                {/* Time Scope */}
                <select
                    value={timeScope}
                    onChange={handleTimeSelect}
                    className="form-control"
                    style={{ width: 'auto', height: '40px' }}
                >
                    <option value="7d">{t('filter.last_7_days')}</option>
                    <option value="30d">{t('filter.last_30_days')}</option>
                    <option value="custom">{t('filter.custom_range')}</option>
                </select>
            </div>

            {/* Custom Family Modal */}
            {customFamilyOpen && (
                <div style={{
                    position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
                    background: 'rgba(0,0,0,0.5)', zIndex: 9999,
                    display: 'flex', justifyContent: 'center', alignItems: 'center'
                }}>
                    <div style={{
                        background: 'var(--bg-card)', padding: '24px', borderRadius: '12px',
                        width: '400px', border: '1px solid var(--border-color)'
                    }}>
                        <h3 style={{ marginTop: 0, marginBottom: '16px' }}>Select Product Families</h3>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', margin: '16px 0', maxHeight: '300px', overflowY: 'auto' }}>
                            {productFamilies.slice(1).map(fam => (
                                <label key={fam.id} style={{ display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer', padding: '8px', borderRadius: '6px', background: 'rgba(255,255,255,0.03)' }}>
                                    <input
                                        type="checkbox"
                                        checked={selectedFamilies.includes(fam.id)}
                                        onChange={(e) => {
                                            if (e.target.checked) setSelectedFamilies([...selectedFamilies, fam.id]);
                                            else setSelectedFamilies(selectedFamilies.filter(f => f !== fam.id));
                                        }}
                                        style={{ width: '16px', height: '16px' }}
                                    />
                                    {fam.label}
                                </label>
                            ))}
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
                            <button onClick={() => setCustomFamilyOpen(false)} className="btn btn-ghost">Cancel</button>
                            <button onClick={applyCustomFamilies} className="btn btn-primary">Apply</button>
                        </div>
                    </div>
                </div>
            )}

            {/* Date Picker Modal */}
            {showDatePicker && (
                <div
                    style={{ position: 'fixed', inset: 0, zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }}
                    onClick={() => setShowDatePicker(false)}
                >
                    <div
                        onClick={e => e.stopPropagation()}
                        style={{ background: '#1c1c1e', padding: '24px', borderRadius: '16px', width: '320px', border: '1px solid rgba(255,255,255,0.1)', boxShadow: '0 20px 40px rgba(0,0,0,0.4)' }}
                    >
                        <h3 style={{ fontSize: '1.1rem', fontWeight: 600, color: '#fff', marginBottom: '20px' }}>选择自定义时间段</h3>

                        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                            <div>
                                <label style={{ display: 'block', textTransform: 'uppercase', fontSize: '0.7rem', color: 'rgba(255,255,255,0.5)', fontWeight: 600, marginBottom: '6px' }}>开始日期</label>
                                <input
                                    type="date"
                                    value={customRange.start}
                                    onChange={e => setCustomRange(prev => ({ ...prev, start: e.target.value }))}
                                    style={{ width: '100%', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', padding: '10px', color: '#fff' }}
                                />
                            </div>
                            <div>
                                <label style={{ display: 'block', textTransform: 'uppercase', fontSize: '0.7rem', color: 'rgba(255,255,255,0.5)', fontWeight: 600, marginBottom: '6px' }}>结束日期</label>
                                <input
                                    type="date"
                                    value={customRange.end}
                                    onChange={e => setCustomRange(prev => ({ ...prev, end: e.target.value }))}
                                    style={{ width: '100%', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', padding: '10px', color: '#fff' }}
                                />
                            </div>
                        </div>

                        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '24px' }}>
                            <button
                                onClick={() => setShowDatePicker(false)}
                                className="px-4 py-2 rounded-lg text-sm text-white/60 hover:text-white"
                            >
                                取消
                            </button>
                            <button
                                onClick={applyCustomDate}
                                disabled={!customRange.start || !customRange.end}
                                className="px-4 py-2 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                确认应用
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {isLoading && tickets.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '60px' }}>
                    <Loader2 size={32} className="animate-spin text-primary" style={{ margin: '0 auto' }} />
                </div>
            ) : tickets.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-secondary)' }}>
                    <MessageSquare size={48} style={{ margin: '0 auto 12px', opacity: 0.5 }} />
                    <p>{t('inquiry_ticket.empty_hint')}</p>
                </div>
            ) : viewMode === 'card' ? (
                /* Card View (Grid) */
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: '24px' }}>
                    {tickets.map(ticket => (
                        <TicketCard key={ticket.id} ticket={ticket} />
                    ))}
                </div>
            ) : (
                /* List View (Grouped Pulse) */
                <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
                    {groupedTickets.urgent.length > 0 && (
                        <section>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px', color: '#ef4444' }}>
                                <AlertTriangle size={18} />
                                <h2 style={{ fontSize: '0.9rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                                    {t('dashboard.urgent_attention')} ({groupedTickets.urgent.length})
                                </h2>
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {groupedTickets.urgent.map(t => <TicketCard key={t.id} ticket={t} />)}
                            </div>
                        </section>
                    )}

                    {groupedTickets.attention.length > 0 && (
                        <section>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px', color: '#f59e0b' }}>
                                <AlertCircle size={18} />
                                <h2 style={{ fontSize: '0.9rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                                    Needs Follow-up ({groupedTickets.attention.length})
                                </h2>
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {groupedTickets.attention.map(t => <TicketCard key={t.id} ticket={t} />)}
                            </div>
                        </section>
                    )}

                    {groupedTickets.active.length > 0 && (
                        <section>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px', color: 'var(--primary)' }}>
                                <Clock size={18} />
                                <h2 style={{ fontSize: '0.9rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                                    {t('dashboard.active_tickets')} ({groupedTickets.active.length})
                                </h2>
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {groupedTickets.active.map(t => <TicketCard key={t.id} ticket={t} />)}
                            </div>
                        </section>
                    )}

                    {groupedTickets.done.length > 0 && (
                        <section style={{ opacity: 0.6 }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px', color: 'var(--text-tertiary)' }}>
                                <CheckCircle size={18} />
                                <h2 style={{ fontSize: '0.9rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                                    {t('inquiry_ticket.status.resolved')} ({groupedTickets.done.length})
                                </h2>
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {groupedTickets.done.map(t => <TicketCard key={t.id} ticket={t} />)}
                            </div>
                        </section>
                    )}
                </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '12px', marginTop: '40px', paddingBottom: '40px' }}>
                    <button
                        onClick={() => setPage(p => Math.max(1, p - 1))}
                        disabled={page === 1}
                        className="btn btn-secondary btn-sm"
                    >
                        <ChevronLeft size={16} />
                    </button>
                    <span style={{ fontSize: '0.875rem' }}>
                        {page} / {totalPages}
                    </span>
                    <button
                        onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                        disabled={page === totalPages}
                        className="btn btn-secondary btn-sm"
                    >
                        <ChevronRight size={16} />
                    </button>
                </div>
            )}
        </div>
    );
};

export default InquiryTicketListPage;
