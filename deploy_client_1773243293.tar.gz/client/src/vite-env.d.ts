/// <reference types="vite/client" />

declare const __APP_VERSION__: string
declare const __APP_COMMIT__: string
declare const __APP_COMMIT_TIME__: string
declare const __APP_BUILD_TIME__: string
declare const __APP_FULL_VERSION__: string
