import { create } from 'zustand';

interface User {
    id: number;
    username: string;
    role: 'Admin' | 'Exec' | 'Lead' | 'Member' | 'Dealer';
    department_name?: string;
    department_code?: string;
    user_type?: 'Internal' | 'Employee' | 'Dealer' | 'Customer';
    job_title?: string;
    display_name?: string;
    dealer_id?: number;
    dealer_name?: string;
}

interface AuthState {
    user: User | null;
    token: string | null;
    setAuth: (user: User, token: string) => void;
    logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
    user: JSON.parse(localStorage.getItem('user') || 'null'),
    token: localStorage.getItem('token'),
    setAuth: (user, token) => {
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('token', token);
        set({ user, token });
    },
    logout: () => {
        localStorage.removeItem('user');
        localStorage.removeItem('token');
        set({ user: null, token: null });
    },
}));
